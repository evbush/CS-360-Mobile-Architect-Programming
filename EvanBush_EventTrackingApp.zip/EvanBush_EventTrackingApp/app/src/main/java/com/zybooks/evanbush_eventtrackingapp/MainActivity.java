package com.zybooks.evanbush_eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements EventController.EditEventListener {

    private TextView currentDate;
    private EventController eventController;
    private EventsDB dbEvents;
    private FloatingActionButton addEventFab;
    private RecyclerView agendaRecyclerView;
    private String selectedDate;

    // Listener for the CalendarView date changes
    private final CalendarView.OnDateChangeListener dateChangeListener = new CalendarView.OnDateChangeListener() {
        @Override
        public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, dayOfMonth);
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
            String selectedDate = dateFormat.format(calendar.getTime());
            currentDate.setText(selectedDate);
            updateEventList(selectedDate);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        // Initialize views
        CalendarView calendarView = findViewById(R.id.calendarView);
        currentDate = findViewById(R.id.selectedDate);
        addEventFab = findViewById(R.id.addEventFab);

        // Initialize the RecyclerView
        agendaRecyclerView = findViewById(R.id.agendaRecyclerView);

        // Set the layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        agendaRecyclerView.setLayoutManager(layoutManager);

        // Initialize events database
        dbEvents = new EventsDB(MainActivity.this);

        // Set the initial selected date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        selectedDate = dateFormat.format(calendar.getTime());
        currentDate.setText(selectedDate);

        List<Event> eventList = fetchEventDataFromDatabase(selectedDate);

        // Create and set up the EventController
        eventController = new EventController(eventList, this);
        agendaRecyclerView.setAdapter(eventController);

        // Set the date change listener
        calendarView.setOnDateChangeListener(dateChangeListener);

        addEventFab.setOnClickListener(view -> {
            showAddEventDialog();
        });

    }

    @Override
    public void onEditButtonClick(Event event) {
        showEditEventDialog(event);
    }

    private List<Event> fetchEventDataFromDatabase(String selectedDate) {
        return dbEvents.getEventsForDate(selectedDate);
    }

    private void showAddEventDialog() {
        AddEvent dialogFragment = new AddEvent();
        dialogFragment.show(getSupportFragmentManager(), "AddEvent");
    }

    private void showEditEventDialog(Event event) {
        EditEvent editEventDialog = EditEvent.newInstance(event);
        editEventDialog.show(getSupportFragmentManager(), "EditEvent");
    }

    public void updateEventList(String selectedDate) {
        List<Event> eventList = fetchEventDataFromDatabase(selectedDate);
        eventController.updateEventList(eventList);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database connection
        dbEvents.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_notify) {
            Intent intent = new Intent(this, NotificationCenter.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onEditEvent(Event event) {
        openEditEventDialog(event);
    }

    private void openEditEventDialog(Event event) {
        EditEvent editEventDialog = new EditEvent();
        editEventDialog.setEvent(event);
        editEventDialog.show(getSupportFragmentManager(), "edit_event_dialog");
    }




}