package com.zybooks.evanbush_eventtrackingapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class NotificationCenter extends AppCompatActivity {

    private SwitchMaterial smsSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notifications_activity);

        smsSwitch = findViewById(R.id.sms_switch);
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> switchToggled(isChecked));
    }

    private boolean notificationPermissionGranted = false; // Track permission status

    private void showPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Notification Permission");
        builder.setMessage("Allow this app to send you notifications?");
        builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                notificationPermissionGranted = true;
                enableNotifications();
            }
        });
        builder.setNegativeButton("Deny", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                notificationPermissionGranted = false;
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void enableNotifications() {
        Toast.makeText(NotificationCenter.this, "Notifications enabled.", Toast.LENGTH_SHORT).show();
    }
    private void disableNotifications() {
        Toast.makeText(NotificationCenter.this, "Notifications disabled.", Toast.LENGTH_SHORT).show();
    }

    private void switchToggled(boolean isChecked) {
        if (isChecked) {
            if (!notificationPermissionGranted) {
                showPermissionDialog();
            } else {
                enableNotifications();
            }
        } else {
            // Disable notifications
            disableNotifications();
        }
    }

}