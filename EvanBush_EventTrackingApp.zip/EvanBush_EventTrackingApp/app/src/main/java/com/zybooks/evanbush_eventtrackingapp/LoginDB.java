package com.zybooks.evanbush_eventtrackingapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "logins.db";
    private static final int VERSION = 1;

    public LoginDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    public long addNewLogin(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USERNAME, username);
        values.put(LoginTable.COL_PASSWORD, password);

        long loginId = db.insert(LoginTable.TABLE, null, values);
        return loginId;
    }

    public Boolean checkUsername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = '" + username + "'";
        Cursor cursor = db.rawQuery(sql, null);

        boolean result = (cursor.getCount() > 0) ? true : false;

        return result;
    }

    public Boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = '" + username + "' and password = '" + password + "'";
        Cursor cursor = db.rawQuery(sql, null);

        boolean result = (cursor.getCount() > 0) ? true : false;

        return result;
    }
}
