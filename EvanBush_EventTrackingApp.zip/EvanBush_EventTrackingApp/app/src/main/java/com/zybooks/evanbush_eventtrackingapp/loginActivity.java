package com.zybooks.evanbush_eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class loginActivity extends AppCompatActivity {

    private EditText mUsername;
    private EditText mPassword;
    private LoginDB dbLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_login);

        mUsername = findViewById(R.id.usernameLogin);
        mPassword = findViewById(R.id.passwordLogin);

        dbLogin = new LoginDB(loginActivity.this);
    }

    public void Login(View view) {
        String username = mUsername.getText().toString();
        String password = mPassword.getText().toString();

        if (username.isEmpty() && password.isEmpty()) {
            Toast.makeText(loginActivity.this, "Fill in username and password.", Toast.LENGTH_SHORT).show();
        }
        else {
            Boolean checkUsername = dbLogin.checkUsername(username);
            Boolean checkLogin = dbLogin.checkLogin(username, password);

            if (!checkUsername) {
                Toast.makeText(loginActivity.this, "User not found. Sign up below.", Toast.LENGTH_SHORT).show();
            }
            else if (checkLogin) {
                Toast.makeText(loginActivity.this, "Login successful.\nWelcome to EventFlow.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(loginActivity.this, MainActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(loginActivity.this, "Password incorrect. Try again.", Toast.LENGTH_SHORT).show();
                mPassword.setText("");
            }
        }
    }

    public void SignUp(View view) {
        String username = mUsername.getText().toString();
        String password = mPassword.getText().toString();

        if (username.isEmpty() && password.isEmpty()) {
            Toast.makeText(loginActivity.this, "Fill in username and password.", Toast.LENGTH_SHORT).show();
        }
        else {
            Boolean checkUsername = dbLogin.checkUsername(username);
            if (!checkUsername) {
                dbLogin.addNewLogin(username, password);

                Toast.makeText(loginActivity.this, "Register Successful.\nWelcome to EventFlow.", Toast.LENGTH_SHORT).show();
                mUsername.setText("");
                mPassword.setText("");
                Intent intent = new Intent(loginActivity.this, MainActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(loginActivity.this, "Username already exists.", Toast.LENGTH_SHORT).show();
            }
        }


    }




}
