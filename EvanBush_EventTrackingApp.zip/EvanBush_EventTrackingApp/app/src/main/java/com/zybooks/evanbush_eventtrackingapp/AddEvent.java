package com.zybooks.evanbush_eventtrackingapp;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.NumberPicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddEvent extends DialogFragment {
    private EditText eventTitle;
    private EditText eventDate;
    private CalendarView eventDateCalendar;
    private EditText eventTime;
    private View timePicker;
    private EventsDB dbEvents;
    private NumberPicker hourPicker;
    private NumberPicker minutePicker;
    private Button confirmButton;
    private final CalendarView.OnDateChangeListener dateChangeListener = new CalendarView.OnDateChangeListener() {

        public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, dayOfMonth);
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
            String selectedDate = dateFormat.format(calendar.getTime());
            eventDate.setText(selectedDate);
            eventDateCalendar.setVisibility(View.GONE);
        }
    };

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_event, null);

        eventTitle = dialogView.findViewById(R.id.eventName);
        eventDate = dialogView.findViewById(R.id.eventDate);
        eventDateCalendar = dialogView.findViewById(R.id.eventDateCalendar);
        eventTime = dialogView.findViewById(R.id.eventTime);

        timePicker = dialogView.findViewById(R.id.timePicker);
        hourPicker = dialogView.findViewById(R.id.hourPicker);
        minutePicker = dialogView.findViewById(R.id.minutePicker);
        confirmButton = dialogView.findViewById(R.id.confirmButton);

        dbEvents = new EventsDB(getActivity());

        // Set NumberPicker ranges and default values
        hourPicker.setMinValue(0);
        hourPicker.setMaxValue(23);

        minutePicker.setMinValue(0);
        minutePicker.setMaxValue(59);

        // Set the initial selected date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        String selectedDate = dateFormat.format(calendar.getTime());
        eventDate.setText(selectedDate);

        // Date change listener
        eventDateCalendar.setOnDateChangeListener(dateChangeListener);
        eventDateCalendar.setVisibility(View.GONE);
        eventDate.setOnClickListener(view -> eventDateCalendar.setVisibility(View.VISIBLE));

        // Time change listener
        timePicker.setVisibility(View.GONE);
        eventTime.setOnClickListener(view -> timePicker.setVisibility(View.VISIBLE));

        // Set confirm button click listener
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedHour = hourPicker.getValue();
                int selectedMinute = minutePicker.getValue();

                String selectedTime = String.format("%02d:%02d", selectedHour, selectedMinute);

                eventTime.setText(selectedTime);
                timePicker.setVisibility(View.GONE);
            }
        });

        builder.setView(dialogView)
                .setPositiveButton("Add Event", (dialog, which) -> {
                    // Save event to the database
                    String title = eventTitle.getText().toString();
                    String date = eventDate.getText().toString();
                    String time = eventTime.getText().toString();
                    Event event = new Event(0, date, title, time);
                    dbEvents.addEvent(event);

                    // Fetch the updated event list and update the event controller in MainActivity
                    MainActivity mainActivity = (MainActivity) getActivity();
                    mainActivity.updateEventList(date);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // Cancel event creation
                    dismiss();
                });

        return builder.create();
    }

    private List<Event> fetchEventDataFromDatabase(String date) {
        return dbEvents.getEventsForDate(date);
    }
}