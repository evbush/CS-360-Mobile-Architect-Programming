package com.zybooks.evanbush_eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class EventsDB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "events.db";
    private static final int VERSION = 1;

    public EventsDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class EventTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "id";
        private static final String COL_DATE = "date";
        private static final String COL_TITLE= "title";
        private static final String COL_TIME= "time";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + EventTable.TABLE + " (" +
                EventTable.COL_ID + " integer primary key autoincrement, " +
                EventTable.COL_DATE + " text, " +
                EventTable.COL_TITLE + " text, " +
                EventTable.COL_TIME + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + EventTable.TABLE);
        onCreate(db);
    }

    public long addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COL_DATE, event.getDate());
        values.put(EventTable.COL_TITLE, event.getTitle());
        values.put(EventTable.COL_TIME, event.getTime());

        long eventId = db.insert(EventTable.TABLE, null, values);
        return eventId;
    }

    public List<Event> getEventsForDate(String date) {
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + EventsDB.EventTable.TABLE + " where date = '" + date + "'";
        Cursor cursor = db.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String eventDate = cursor.getString(1);
            String title = cursor.getString(2);
            String time = cursor.getString(3);
            Event event = new Event(id, eventDate, title, time);
            events.add(event);
        }

        cursor.close();
        return events;
    }

    public int updateEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COL_DATE, event.getDate());
        values.put(EventTable.COL_TITLE, event.getTitle());
        values.put(EventTable.COL_TIME, event.getTime());

        String selection = EventTable.COL_ID + " = ?";
        String[] selectionArgs = {String.valueOf(event.getId())};

        return db.update(EventTable.TABLE, values, selection, selectionArgs);
    }

    public int deleteEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();

        String selection = EventTable.COL_ID + " = ?";
        String[] selectionArgs = {String.valueOf(event.getId())};

        return db.delete(EventTable.TABLE, selection, selectionArgs);
    }
}
