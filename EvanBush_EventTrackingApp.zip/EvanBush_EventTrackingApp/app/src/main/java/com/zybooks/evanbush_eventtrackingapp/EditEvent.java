package com.zybooks.evanbush_eventtrackingapp;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.NumberPicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EditEvent extends DialogFragment {

    private Event event;
    private EditText eventTitle;
    private EditText eventDate;
    private CalendarView eventDateCalendar;
    private EditText eventTime;
    private View timePicker;
    private EventsDB dbEvents;
    private NumberPicker hourPicker;
    private NumberPicker minutePicker;
    private Button confirmButton;
    private final CalendarView.OnDateChangeListener dateChangeListener = new CalendarView.OnDateChangeListener() {

        public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, dayOfMonth);
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
            String selectedDate = dateFormat.format(calendar.getTime());
            eventDate.setText(selectedDate);
            eventDateCalendar.setVisibility(View.GONE);
        }
    };

    public static EditEvent newInstance(Event event) {
        EditEvent fragment = new EditEvent();
        Bundle args = new Bundle();
        args.putParcelable("event", event);
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_event, null);

        // Initialize the views
        eventTitle = dialogView.findViewById(R.id.eventName);
        eventDate = dialogView.findViewById(R.id.eventDate);
        eventDateCalendar = dialogView.findViewById(R.id.eventDateCalendar);
        eventTime = dialogView.findViewById(R.id.eventTime);
        timePicker = dialogView.findViewById(R.id.timePicker);

        hourPicker = dialogView.findViewById(R.id.hourPicker);
        minutePicker = dialogView.findViewById(R.id.minutePicker);
        confirmButton = dialogView.findViewById(R.id.confirmButton);

        dbEvents = new EventsDB(getActivity());

        // Set NumberPicker ranges and default values
        hourPicker.setMinValue(0);
        hourPicker.setMaxValue(23);

        minutePicker.setMinValue(0);
        minutePicker.setMaxValue(59);

        // Set initial selected date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        String selectedDate = dateFormat.format(calendar.getTime());
        eventDate.setText(selectedDate);

        // Date change listener
        eventDateCalendar.setOnDateChangeListener(dateChangeListener);
        eventDateCalendar.setVisibility(View.GONE);
        eventDate.setOnClickListener(view -> eventDateCalendar.setVisibility(View.VISIBLE));

        // Time change listener
        timePicker.setVisibility(View.GONE);
        eventTime.setOnClickListener(view -> timePicker.setVisibility(View.VISIBLE));

        // Set confirm button click listener
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedHour = hourPicker.getValue();
                int selectedMinute = minutePicker.getValue();

                String selectedTime = String.format("%02d:%02d", selectedHour, selectedMinute);

                eventTime.setText(selectedTime);
                timePicker.setVisibility(View.GONE);
            }
        });

        Intent intent = requireActivity().getIntent();
        if (intent != null && intent.hasExtra("event")) {
            Event event = intent.getParcelableExtra("event");
            if (event != null) {
                eventTitle.setText(event.getTitle());
                eventDate.setText(event.getDate());
                eventTime.setText(event.getTime());
            }
        }

        builder.setView(dialogView)
                .setPositiveButton("Save Changes", (dialog, which) -> {
                    // Save the changes to the event
                    String title = eventTitle.getText().toString();
                    String date = eventDate.getText().toString();
                    String time = eventTime.getText().toString();
                    Event event = new Event(0, date, title, time);
                    // Update the event in the database
                    dbEvents.updateEvent(event);
                    // Notify the MainActivity to update the event list
                    EditEventListener listener = (EditEventListener) getActivity();
                    if (listener != null) {
                        listener.onEventEdited(event);
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // Dismiss the dialog
                    dialog.dismiss();
                });

        return builder.create();
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public interface EditEventListener {
        void onEventEdited(Event event);
    }
}
