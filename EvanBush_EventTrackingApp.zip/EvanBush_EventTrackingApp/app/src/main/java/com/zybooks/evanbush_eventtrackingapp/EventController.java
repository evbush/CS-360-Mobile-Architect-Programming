package com.zybooks.evanbush_eventtrackingapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventController extends RecyclerView.Adapter<EventController.ViewHolder> {

    private List<Event> eventList;
    private EditEventListener editEventListener;

    public EventController(List<Event> events, EditEventListener listener) {
        this.eventList = events;
        this.editEventListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Event event = eventList.get(holder.getAdapterPosition());

        holder.eventTitleTextView.setText(event.getTitle());
        holder.eventTimeTextView.setText(event.getTime());

        // Wasn't able to figure out how to fully implement this. I was able to pass event data between activities
        // and fragments through Parcelable , but I wasn't able to grab what I needed. I ran out of time. I'm sure it would have came
        // to me soon or later
//        // Set click listener for the edit button
//        holder.editButton.setOnClickListener(v -> {
//            if (editEventListener != null) {
//                editEventListener.onEditEvent(event);
//            }
//        });

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Display a confirmation dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle("Confirm Delete")
                        .setMessage("Are you sure you want to delete this event?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                int position = holder.getAdapterPosition();
                                if (position != RecyclerView.NO_POSITION) {
                                    Event event = eventList.get(position);
                                    EventsDB eventsDB = new EventsDB(v.getContext());
                                    eventsDB.deleteEvent(event);

                                    // Remove the event from the list and notify the adapter
                                    eventList.remove(position);
                                    notifyItemRemoved(position);
                                }
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView eventTitleTextView;
        private TextView eventTimeTextView;
        private ImageButton editButton;
        private ImageButton deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            eventTitleTextView = itemView.findViewById(R.id.eventTitleTextView);
            eventTimeTextView = itemView.findViewById(R.id.eventTimeTextView);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    public void updateEventList(List<Event> updatedEventList) {
        this.eventList = updatedEventList;
        notifyDataSetChanged();
    }

    public interface EditEventListener {
        void onEditButtonClick(Event event);

        void onEditEvent(Event event);
    }
}