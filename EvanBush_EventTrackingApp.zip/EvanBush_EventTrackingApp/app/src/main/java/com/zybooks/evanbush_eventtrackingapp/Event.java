package com.zybooks.evanbush_eventtrackingapp;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Event implements Parcelable {
    private int id;
    private String date;
    private String title;
    private String time;

    public Event(int id, String date, String title, String time) {
        this.id = id;
        this.date = date;
        this.title = title;
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getTitle() {
        return title;
    }

    public String getTime() {
        return time;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDate(String date) {
        this.title = date;
    }

    public void setTime(String time) {
        this.title = time;
    }

    // Parcelable implementation
    protected Event(Parcel in) {
        id = in.readInt();
        date = in.readString();
        title = in.readString();
        time = in.readString();
    }

    public static final Creator<Event> CREATOR = new Creator<Event>() {
        @Override
        public Event createFromParcel(Parcel in) {
            return new Event(in);
        }

        @Override
        public Event[] newArray(int size) {
            return new Event[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(date);
        dest.writeString(title);
        dest.writeString(time);
    }
}
